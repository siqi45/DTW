package com.tubai.algorithm.dtw;

public class DtwAlgorithm {
    public static void main(String[] args) throws Exception {
        double s1[] =   {1, 2, 0, 1, 1, 2, 0, 1, 1, 2, 0, 1, 1, 2, 0, 1};
        double s2[] =   {0, 1, 1, 2, 0, 1, 1, 2, 0, 1, 1, 2, 0, 1, 1, 2};
        //double s2[] = {0, 1, 1, 2, 0, 1, 1.7, 2, 0, 1, 1, 2, 0, 1, 1, 2};
        double s3[] =   {0.8,1.5, 0, 1.2, 0, 0, 0.6, 1, 1.2, 0, 0, 1, 0.2, 2.4, 0.5, 0.4};
        System.out.println("dtw(s1,s2) = " + dtw(s1,s2));
        System.out.println("dtw(s1,s3) = " + dtw(s1,s3));
    }

    public static double dtw(double[] s1,double[] s2) throws Exception {
        double dist11 = DTW1.calDTW1(s1, s2);
        double dist12 = DTW2.calDTW2(s1, s2);
        double avg12 = (dist11+dist12)/2;
        return 1/(1+avg12);
    }
}
