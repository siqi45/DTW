package com.tubai.algorithm.dtw;

class Point implements Comparable<Point>{
    int x,y;

    @Override
    public String toString() {
        return "Point{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }

    Point(int x, int y){
        this.x = x;
        this.y = y;
    }

    @Override
    public int compareTo(Point o) {
        if(x==o.x){
            return y-o.y;
        }
        return x-o.x;
    }
}