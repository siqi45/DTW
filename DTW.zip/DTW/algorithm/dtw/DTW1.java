package com.tubai.algorithm.dtw;

import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

public class DTW1 {
    private static final int N = 500+10;

    private static double dis(double a,double b){
        return (a-b)*(a-b);
    }
    /**
     * 基本的DTW
     * @param a
     * @param b
     * @return
     */
    private static double[][] baseDTW(double [] a, double [] b){
        double dp[][] = new double[N][N];
        for(int i=0;i<N;++i){
            for(int j=0;j<N;++j) dp[i][j]=Double.POSITIVE_INFINITY;
        }
        int n = a.length,m = b.length;
        dp[0][0] = 0;
        //这里不需要处理边界，因此第一行和第一列直接pass 给个INF
        for(int i=0;i<n;++i){
            for(int j=0;j<m;++j){
            /*if(i==0&&j==0) dp[i][j]=dis(a[0],b[0]);
            else if(i==0) dp[i][j]=dp[0][j-1]+dis(a[0],b[j]);
            else if(j==0) dp[i][j]=dp[i-1][0]+dis(a[i],b[0]);
            else dp[i][j] = dis(a[i],b[j])+Math.min(dp[i-1][j-1],Math.min(dp[i-1][j],dp[i][j-1]));*/
                dp[i+1][j+1] = dis(a[i],b[j]) + Math.min(dp[i][j],Math.min(dp[i+1][j],dp[i][j+1]));
            }
        }
        return dp;
    }

    private static double sqrt(double a){
        return Math.sqrt(a);
    }

    public static double calDTW1(double[] s1, double[] s2) throws Exception {
        double[][] dp = baseDTW(s1, s2);
        int n = s1.length+1,m = s2.length+1;
        //t_dp是转置后的矩阵
        double[][] t_dp = matrixTMethod(n, m, dp);
        //besePath里面存的是最优路径的节点，后续用于代入公式中 -> 得到最优路径节点数
        List<Point> bestPath = getBestPath(m, n, t_dp);
        //diagonalLens(i) 表示第i段对角直线的长度
        List<Integer> diagonalLens = getDiagonalLineLength(bestPath);
        double p1 = getAttenuationParam(bestPath.size(), diagonalLens);
        double similarDist = p1*sqrt(dp[n-1][m-1]);
        //System.out.println("相似距离=>"+similarDist);
        return similarDist;
    }


    private static List<Integer> getDiagonalLineLength(List<Point> pathList) {
        List<Integer> beforeFilterList = new LinkedList<>();
        Point pre = pathList.get(0);
        int len = 1;
        for (int i = 1; i < pathList.size(); i++) {
            Point cur = pathList.get(i);
            if(cur.x==pre.x+1&&cur.y==pre.y+1){
                //ok
                ++len;
            }else{
                beforeFilterList.add(len);
                len = 1;
            }
            pre = cur;
        }
        beforeFilterList.add(len);
        //过滤没用的点
        List<Integer> retList = new LinkedList<>();
        for (int i = 0,tmp; i < beforeFilterList.size(); i++) {
            tmp = beforeFilterList.get(i);
            if(tmp>1) retList.add(tmp);
        }
        return retList;
    }

    /**
     * 0表示a最小 1表示b最小 2表示c最小
     * @param a
     * @param b
     * @param c
     * @return
     */
    private static int getMinPos(double a,double b,double c){
        if(a-b<1e-7){
            if(a-c<1e-7){
                //a
                return 0;
            }else{
                //c
                return 2;
            }
        }else{
            if(b-c<1e-7){
                //b
                return 1;
            }else{
                //c
                return 2;
            }
        }
    }

    /**
     * 获取衰减系数
     * @return
     */
    private static double getAttenuationParam(int seqLen,List<Integer> diagonalLens){
        //根号里面那堆东西
        double val = 0;
        double powSeqLen = seqLen*seqLen;
        for (Integer len : diagonalLens) {
            val += (len*len)/powSeqLen;
        }
        return 1-Math.sqrt(val);
    }

    /**
     * 矩阵转置
     */
    private static double[][] matrixTMethod(int n, int m, double[][]dp){
        double[][] new_dp = new double[N][N];
        for(int i=0;i<n;++i){
            for(int j=0;j<m;++j){
                new_dp[j][i] = dp[i][j];
            }
        }
        return new_dp;
    }

    /**
     * 为了计算最优路径节点个数
     * @param n
     * @param m
     * @param path
     * @return
     * @throws Exception
     */
    private static List<Point> getBestPath(int n, int m, double[][] path) throws Exception {
        List<Point> list = new LinkedList<>();
        //从(n,m)往回走
        int i=n-1,j=m-1;
        if(path[i][j]!=Double.POSITIVE_INFINITY) list.add(new Point(i-1,j-1));
        while(i>0&&j>0){
            int pos = getMinPos(path[i - 1][j - 1], path[i][j - 1], path[i - 1][j]);
            if(pos==0){
                --i;
                --j;
            }else if(pos==1){
                --j;
            }else if(pos==2){
                --i;
            }else{
                throw new Exception("DTW获取最佳路径异常!");
            }
            if(i>0&&j>0) list.add(new Point(i-1,j-1));
        }
        Stack<Point> stack = new Stack<>();
        for (Point point : list) {
            stack.push(point);
        }
        //反转list
        List<Point> ret = new LinkedList<>();
        while(!stack.empty()){
            ret.add(stack.pop());
        }
        return ret;
    }

    private static void printSimilar(double dist){
        System.out.println("相似度=>"+(1/(1+dist)));
    }

    private static <T> void printMatrix(int n,int m,T[][] dp) {
        for(int i=0;i<n;++i){
            for(int j=0;j<m;++j){
                System.out.print(dp[i][j]);
                System.out.print("\t");
            }
            System.out.println();
        }
    }
}
