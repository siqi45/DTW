package com.tubai.algorithm.dtw;

import java.util.HashMap;
import java.util.Map;

public class DTW2 {
    public static double calDTW2(double[] s1,double[] s2) {
        Map<String, Object> map = baseDTW(s1, s2);
        Integer max_substr_len1 = (Integer) map.get("max_substr_len");
        Double sqrt_dist1 = (Double) map.get("sqrt_dist");
        double p1 = getAttenuationParam(s1.length,s2.length,max_substr_len1);
        double similarDist = p1*sqrt_dist1;
        return similarDist;
    }

    private static Map<String,Object> baseDTW(double[] a, double[] b) {
        double maxStd = getMaxStd(a, b);
        final int N = 510;
        double dp[][] = new double[N][N];
        Integer[][] f = new Integer[N][N];
        int ans = 0;
        for(int i=0;i<N;++i){
            for(int j=0;j<N;++j) {
                dp[i][j]=Double.POSITIVE_INFINITY;
                f[i][j]=0;
            }
        }
        int n = a.length,m = b.length;
        dp[0][0] = 0;
        for(int i=0;i<n;++i){
            for(int j=0;j<m;++j){
                dp[i+1][j+1] = dis(a[i],b[j]) + Math.min(dp[i][j],Math.min(dp[i+1][j],dp[i][j+1]));
                //小于这个标准差都认为是相等的
                if(Math.abs(a[i]-b[j])<maxStd){
                    //dp求最长公共子串
                    if(i==0||j==0) f[i][j] = 1;
                    else f[i][j] = 1 + f[i-1][j-1];
                    ans = Math.max(ans,f[i][j]);
                }
            }
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("sqrt_dist",Math.sqrt(dp[n][m]));
        map.put("max_substr_len",ans);
        return map;
    }

    /**
     * 获取衰减系数
     * @return
     */
    private static double getAttenuationParam(int len1,int len2,int max_substr_len){
        return 1-(1.0*max_substr_len/len1*max_substr_len/len2);
    }

    private static double dis(double a,double b){
        return (a-b)*(a-b);
    }

    private static double getMaxStd(double[] p, double[] q) {
        return Math.max(
                getStd(p),getStd(q)
        );
    }

    /**
     * 这里是样本标准差 除以的是（n-1)
     * 而如果要计算总体标准差 应该除以 n
     * @param arr
     * @return
     */
    private static double getStd(double[] arr) {
        double ret = 0;
        double avg = getAvg(arr);
        for(int i=0;i<arr.length;++i){
            ret+=((arr[i]-avg)*(arr[i]-avg));
        }
        ret/=arr.length-1;
        ret = Math.sqrt(ret);
        return ret;
    }

    private static double getAvg(double [] arr) {
        double sum = 0;
        for(int i=0;i<arr.length;++i){
            sum+=arr[i];
        }
        return sum/arr.length;
    }
}