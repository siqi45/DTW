package com.tubai.algorithm.grayEvaluation;

import java.util.ArrayList;
import java.util.List;

public class GrayAlgorithm {
    /**
     * n*m矩阵
     */
    private static double[][] input = {
            {10, 18, 26, 35, 43, 55, 67, 79, 82, 84, 86, 88, 90},
            {105.2, 105.9, 106.1, 105.7, 106.8, 107.5, 108, 110.1, 117.1, 109.6, 110.3, 111, 111.7},
            {101.7, 101.7, 101.7, 101.7, 101.6, 101.5, 101.4, 101.5, 101.6, 101.8, 101.8, 101.9, 102.1},
            {98.9, 98.7, 98.8, 99, 99.2, 98.8, 98.5, 98.7, 99.3, 100.1, 99.8, 100.4, 100.8},
            {99.3, 99.5, 99.7, 100, 100.2, 100.4, 100.4, 100.5, 100.7, 101.2, 101.4, 101.4, 101.9},
            {102.5, 102.8, 103.2, 103.2, 103.3, 103.3, 103.4, 103.7, 104, 104, 103.2, 103, 103.2},
            {100, 100, 100.1, 99.7, 99.3, 99.4, 99.3, 99.5, 99.3, 99.3, 99.9, 99.7, 100.1},
            {100.3, 100.4, 100.6, 100.9, 101.1, 101.2, 101.2, 100.9, 100.6, 100.7, 101, 100.3, 100.5},
            {100.3, 104.5, 105, 105, 104.8, 104.4, 104.3, 104.9, 105.8, 106, 106.8, 106.1, 106.6}
    };

    public static double[][] getInput() {
        return input;
    }

    public static void setInput(double[][] var1) {
        input = var1;
    }

    public static List<Double> getRealVal() {
        ArrayList<Double> realVal = new ArrayList<>();
        //realVal1 是一个行向量
        double[][] realVal1 = getRealValArray();
        for (int j = 0; j < realVal1[0].length; ++j) {
            realVal.add(realVal1[0][j]);
        }
        return realVal;
    }

    private static double[][] getRealValArray() {
        double[][] realVal1 = Gray1.getGrayPartOne(input);
        return realVal1;
    }

    public static List<Double> getGuessVal() {
        ArrayList<Double> guessVal = new ArrayList<>();
        double[][] realVal = getRealValArray();
        //guessVal1 是一个行向量
        double[][] guessVal1 = Gray2.getGrayPartTwo(realVal);
        for (int j = 0; j < guessVal1[0].length; ++j) {
            guessVal.add(guessVal1[0][j]);
        }
        return guessVal;
    }
}
