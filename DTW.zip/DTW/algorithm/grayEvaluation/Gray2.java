package com.tubai.algorithm.grayEvaluation;

import com.tubai.utils.MatrixUtils;

public class Gray2 {

    /**
     * 前缀和
     *
     * @param realVal 是一个1*m的列向量
     * @return
     */
    private static double[][] getPreSum(double[][] realVal) {
        int col = MatrixUtils.getCol(realVal);
        double[][] preSum = new double[1][col];
        preSum[0][0] = realVal[0][0];
        for (int j = 1; j < col; ++j) {
            preSum[0][j] = preSum[0][j - 1] + realVal[0][j];
        }
        return preSum;
    }


    /**
     * 返回一个z(i)
     * z(i)为的紧邻均值生成序列
     *
     * @param preSum
     * @return
     */
    private static double[][] getAdjacentAvg(double[][] preSum) {
        int col = MatrixUtils.getCol(preSum);
        double[][] z = new double[1][col - 1];
        for (int j = 0; j < col - 1; ++j) {
            z[0][j] = (preSum[0][j] + preSum[0][j + 1]) / 2;
        }
        return z;
    }

    /**
     * Yn为常数项向量
     * 将realVal的第一个元素舍弃 并且转置成列向量
     *
     * @param realVal
     * @return
     */
    private static double[][] getConstantVector(double[][] realVal) {
        int col = MatrixUtils.getCol(realVal);
        double[][] Yn = new double[1][col - 1];
        for (int j = 1; j < col; ++j) {
            Yn[0][j - 1] = realVal[0][j];
        }
        Yn = MatrixUtils.T(Yn);
        return Yn;
    }

    /**
     * 累加生成数据做均值
     * 获取生成矩阵
     *
     * @param z 一个行向量
     * @return 返回一个2*m的矩阵
     */
    private static double[][] getGeneratedMatrix(double[][] z) {
        int col = MatrixUtils.getCol(z);
        double[][] e = new double[2][col];
        for (int j = 0; j < col; ++j) {
            e[0][j] = -z[0][j];
            e[1][j] = 1;
        }
        e = MatrixUtils.T(e);
        return e;
    }

    /**
     * 为了获取a和u
     *
     * @param e
     * @param Yn
     * @return
     */
    private static double[][] getC(double[][] e, double[][] Yn) {
        double[][] ee = MatrixUtils.T(e);
        double[][] mul1 = MatrixUtils.mul(ee, e);
        double[][] mul2 = MatrixUtils.mul(ee, Yn);
        double[][] inv = MatrixUtils.inv(mul1);
        double[][] c = MatrixUtils.mul(inv, mul2);
        return c;
    }

    private static double getA(double[][] c) {
        return c[0][0];
    }

    private static double getU(double[][] c) {
        return c[1][0];
    }

    private static double[][] getF(double[][] c, double[][] A) {
        double a = getA(c);
        double u = getU(c);
        double a1 = A[0][0];
        int ACol = MatrixUtils.getCol(A);
        double[][] F = new double[1][ACol];
        F[0][0] = a1;
        for (int i = 1; i < ACol; ++i) {
            F[0][i] = (a1 - u / a) / Math.exp(a * (i)) + u / a;
        }
        return F;
    }

    /**
     * 获取预测行向量
     *
     * @param F 行向量
     * @return
     */
    private static double[][] getGuessVal(double[][] F) {
        int col = MatrixUtils.getCol(F);
        double[][] G = new double[1][col];
        G[0][0] = F[0][0];
        for (int i = 1; i < col; ++i) {
            G[0][i] = F[0][i] - F[0][i - 1];
        }
        return G;
    }

    public static double[][] getGrayPartTwo(double[][] realVal) {
        double[][] preSum = getPreSum(realVal);
        double[][] z = getAdjacentAvg(preSum);
        double[][] Yn = getConstantVector(realVal);
        double[][] e = getGeneratedMatrix(z);
        double[][] c = getC(e, Yn);
        double[][] F = getF(c, realVal);
        double[][] guessVal = getGuessVal(F);
        return guessVal;
    }
}
