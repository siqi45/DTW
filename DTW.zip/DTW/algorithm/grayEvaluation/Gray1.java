package com.tubai.algorithm.grayEvaluation;

import com.tubai.utils.MatrixUtils;

public class Gray1 {
    public static double[][] getGrayPartOne(double[][] input) {
        int n = input.length;//有几个一维数组(行)
        int m = input[0].length;//一个一维数组的长度是多少(列)
        double[][] y1 = mean(MatrixUtils.T(input));
        y1 = MatrixUtils.T(y1);
        double[][] y2 = meanChange(input, y1);
        double[][] y3 = getDiffSeq(y2);
        double[][] realVal = getRealVal(y3);
        return realVal;
    }

    /**
     * 根据y3构造过渡矩阵y4,由y4算出realVal
     *
     * @param y3
     * @return 返回灰度算法一的结果，即真实数据部分
     */
    private static double[][] getRealVal(double[][] y3) {
        double mx = 0, mn = 1;//y3的元素都在(0,1)之间
        int row = MatrixUtils.getRow(y3);
        int col = MatrixUtils.getCol(y3);
        for (int i = 0; i < row; ++i) {
            for (int j = 0; j < col; ++j) {
                if (y3[i][j] <= mn) {
                    mn = y3[i][j];
                } //这个else if 具体看matlab
                else if (y3[i][j] >= mx) {
                    mx = y3[i][j];
                }
            }
        }
        double[][] y4 = new double[row][col];
        double p = 0.5 * mx;
        //行向量
        double[][] realVal = new double[1][row];
        for (int i = 0; i < row; ++i) {
            double avg = 0;
            for (int j = 0; j < col; ++j) {
                y4[i][j] = (mn + p) / (y3[i][j] + p);
                avg += y4[i][j];
            }
            avg /= col - 1;//这个col-1具体看matlab
            realVal[0][i] = avg;
        }
        return realVal;
    }

    /**
     * 差序列
     *
     * @param y2
     * @return 需要元素x满足 0 < x < 1
     */
    private static double[][] getDiffSeq(double[][] y2) {
        int row = MatrixUtils.getRow(y2);
        int col = MatrixUtils.getCol(y2);
        double[][] y3 = new double[row - 1][col];
        for (int i = 1; i < row; ++i) {
            for (int j = 0; j < col; ++j) {
                y3[i - 1][j] = Math.abs(y2[i][j] - y2[i - 1][j]);
            }
        }
        return y3;
    }

    /**
     * 均值化变换，用于取得y2
     *
     * @param y  n*m 矩阵
     * @param y1 是一个行向量
     */
    private static double[][] meanChange(double[][] y, double[][] y1) {
        int row = MatrixUtils.getRow(y);
        int col = MatrixUtils.getCol(y);
        double[][] y2 = new double[row][col];
        for (int i = 0; i < row; ++i) {
            for (int j = 0; j < col; ++j) {
                y2[i][j] = y[i][j] / y1[i][0];
            }
        }
        return y2;
    }

    private static void printMatrix(double[][] matrix) {
        int row = MatrixUtils.getRow(matrix);
        int col = MatrixUtils.getCol(matrix);
        for (int i = 0; i < row; ++i) {
            for (int j = 0; j < col; ++j) {
                System.out.print(String.format("%.4f", matrix[i][j]));
                System.out.print(" ");
            }
            System.out.println();
        }
    }

    /**
     * 对每一列求平均值
     *
     * @param matrix
     * @return
     */
    private static double[][] mean(double[][] matrix) {
        int row = MatrixUtils.getRow(matrix);
        int col = MatrixUtils.getCol(matrix);
        double[][] ret = new double[1][col];
        for (int j = 0; j < col; ++j) {
            double sum = 0;
            for (int i = 0; i < row; ++i) {
                sum += matrix[i][j];
            }
            ret[0][j] = sum / row;
        }
        return ret;
    }


}
